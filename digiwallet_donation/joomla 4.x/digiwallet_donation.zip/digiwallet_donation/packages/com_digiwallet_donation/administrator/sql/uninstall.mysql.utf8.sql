DROP TABLE IF EXISTS `#__digiwallet_donation_buttons`;
DROP TABLE IF EXISTS `#__digiwallet_donation_configuration`;
DROP TABLE IF EXISTS `#__digiwallet_donation`;
